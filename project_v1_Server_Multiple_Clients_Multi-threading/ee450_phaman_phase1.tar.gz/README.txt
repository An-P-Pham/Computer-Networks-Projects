a) An Pham
b) 9477698118
c) Part 1 of Project
d) Developed a Server that can handle multiple clients and process their information. 
e)make. Start ./admissions then start departments ./department
h) reused code from lab2\beej's guide\//https://www.geeksforgeeks.org/creating-multiple-process-using-fork/ for learning how to fork
