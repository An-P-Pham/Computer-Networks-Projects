#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <fstream>
#include <sstream>
#include <iostream> 
#include <vector>

#define port_num "3418"

class department{
private:
	//keep track of the server's info
	int sock;
	struct addrinfo server, *serverinfo, *p;
	int rv;

	//keep track of my own info
	struct sockaddr_in my_addr;
	char ip_addr[16];
	unsigned int my_port;
	socklen_t addr_size; 

	//extra data members for sending/recieving 
	char buffer[256]; //buffer for recieving messages
	std::vector<std::string> data;
	std::string my_dep;
	unsigned int filesize; 
public:
	department(std::string dep_name);
	~department();
	void loadfile(std::string filename);
	void sendfile();
	void printdata();
	int sendall(int s, char* buf, int* len);
};

department::department(std::string dep_name)
{
	my_dep = dep_name;

	//sets up the struct
	memset(&server, 0, sizeof(server));
	server.ai_family = AF_UNSPEC;
	server.ai_socktype = SOCK_STREAM;

	//grabs information of server & load into our class
	if(( rv = getaddrinfo("viterbi-scf2.usc.edu", port_num, &server, &serverinfo)) != 0)
	{
		std::cout << "Error getting info" << std::endl;
		exit(1);
	} 

	for(p = serverinfo; p != NULL; p = p->ai_next){
		if((sock = socket(p->ai_family, p->ai_socktype, p->ai_protocol)) == -1)
		{
			perror("Socket Error");
			continue;	
		}

		if(connect(sock, p->ai_addr, p->ai_addrlen) == -1){
			perror("Connect Error");
			close(sock);
			continue;
		}

		break;
	}

	if( p == NULL){
		std::cout << "Failed to connect" << std::endl;
		exit(2);
	}
	
	//find my own ip/port
	my_port = 0;
	while(my_port == 0){
		bzero(&my_addr, sizeof(addr_size));
		getsockname(sock, (struct sockaddr *) &my_addr, &addr_size);
		inet_ntop(AF_INET, &my_addr.sin_addr, ip_addr, sizeof(ip_addr));
		my_port = ntohs(my_addr.sin_port);
	}
	std::cout << my_dep << " has TCP port: " << my_port << " and IP address: " << ip_addr << std::endl;
	std::cout << my_dep << " is now connected to the admission office" << std::endl;

	freeaddrinfo(serverinfo); //done with it - to prevent leaks
}

department::~department()
{
	close(sock);
}

void department::loadfile(std::string filename)
{
	filesize = 0;
	std::ifstream input(filename.c_str());
	std::string line; //used to parse the file
	while(std::getline(input, line))
	{
		char dep_info[line.length() + 1];
		strcpy(dep_info, line.c_str());
		data.push_back(dep_info);
		filesize++;
	}
}

int department::sendall(int s, char* buf, int* len)
{
	int total = 0;
	int bytesleft = *len;
	int n;

	while(total < *len){
		n = send(s, buf+total, bytesleft, 0);
		if(n == -1) {break;}
		total == n;
		bytesleft -= n;
	}

	*len = total; //return number actually sent

	return n==-1? -1:0; //-1 on failure and 0 on success
}

void department::sendfile()
{
	
	int i=0;
	while(i != filesize)
	{
		char char_array[data[i].length() + 1];
		strcpy(char_array, data[i].c_str());
		int len = strlen(char_array);
		send(sock, char_array, len, 0); //re-try until u can send it
		std::cout << my_dep << " has sent " << char_array << " to the admission office" << std::endl;
		i++;
		
	}

	std::cout << "Updating the admission office is done for " << my_dep << std::endl;
	std::cout << "End of Phase 1 for " << my_dep << std::endl; 
}

int main(int argc, char* argv[])
{

	std::string filename;
	std::vector<department> total_departments;
	int n1 = fork(); //creates first child

	int n2 = fork(); //creates 2nd child and grandchild

	if(n1 > 0 && n2 > 0){
		//parent have it do nothing

	}
	else if(n1 == 0 && n2 > 0) //first child
	{
		
		filename = "departmentA";
		department depA(filename);
		filename += ".txt";
		depA.loadfile(filename);
		depA.sendfile();
	}
	else if(n1 > 0 && n2 == 0) //second child
	{
		filename = "departmentB";
		department depB(filename);
		filename += ".txt";
		depB.loadfile(filename);
		depB.sendfile();
	}
	else //third child 
	{
		
		filename = "departmentC";
		department depC(filename);
		filename += ".txt";
		depC.loadfile(filename);
		depC.sendfile();

	}

	return 0;
}