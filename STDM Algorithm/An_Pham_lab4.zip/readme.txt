i. Student Info
Name: An Pham
ID: 9477698118

ii. Compilation Steps
g++ -std=c++11 STDM.cpp -o STDM

iii. Additional Information 
To Run:
./STDM input.txt